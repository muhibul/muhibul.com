<ul class="nav navbar-nav">					
	<li class="current_page_item"><a href="<?php echo admin_url('nav-menus.php'); ?>" class="nav-callback"><?php echo __( 'Set Up Your Menu:', 'wp-profile' ) ?></a></li>
</ul>