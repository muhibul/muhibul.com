﻿=== WP Profile ===

Tags: custom-menu, full-width-template, post-formats
Requires at least: 4.0
Tested up to: 4.3-alpha
Copyright (c) 2015 by Invictus Themes (http://invictusthemes.com/)
This Theme is distributed under the terms of the GNU GPL.

License: GNU General Public License v2.0
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WP Profile is based on Underscores http://underscores.me/, (C) 2012-2014 Automattic, Inc.
===========
ABOUT THEME
WP Profile WP Profile is a simple and straight up blogging theme. It is fully responsive and features two
main navigation menus and a range of quick customization options such as the ability to upload your own logo, 
set primary theme colors, set the featured home page post and chose whether to display author bios.



For free themes support, please contact us http://invictusthemes.com/contact/


============================================
Images Copyright/License Info
============================================
 * All the graphics bundled with this theme are created by the theme author and licensed under the GNU GPL.

 * The photo used in the screenshot.png was downloaded from pixabay.com and is bound to Creative Commons Deed
CC0 as stated in their Terms of Service and Privacy Policy (http://pixabay.com/en/service/terms/)
	http://pixabay.com/en/james-stewart-man-person-actor-392932/
	http://pixabay.com/en/skyline-sunset-buildings-cityscape-200679/
	http://pixabay.com/en/buildings-mosque-sunset-silhouette-203194/
	http://pixabay.com/en/aspen-colorado-sky-courthouse-242553/
	http://pixabay.com/en/santa-cruz-southern-architecture-214609/
	
 
   License URI: http://creativecommons.org/publicdomain/zero/1.0/deed.en
 
============================================
html5shiv.js Copyright/License Info
============================================
 * HTML5 Shiv 3.7.3-pre | MIT/GPL2 Licensed


============================================
ie-responsive.min.js Copyright/License Info
============================================
 * Respond.js v1.4.2 
 * Licensed under https://github.com/scottjehl/Respond/blob/master/LICENSE-MIT

============================================
This theme uses Font Awesome for the theme icons
============================================
 * Font Awesome (http://fortawesome.github.io/Font-Awesome/icons/)
 * Copyright (c) Automattic (http://fortawesome.github.io/Font-Awesome/)
 * Available under the terms of GNU GPL.
 
 
======================================
This theme uses Bootstrap as a design tool
======================================
 * Bootstrap (http://getbootstrap.com/)
 * Copyright (c) 2011-2014 Twitter, Inc
 * Licensed under https://github.com/twbs/bootstrap/blob/master/LICENSE

Version 1.2
bug fixes below:
 * style.php
 * footer.php
 * index.php
 * inc/customizer.php
 * inc/widget-post.php
 * wp-profile-menu.php
 * functions.php
Added template file
 * template-home.php
Remove template file
 * template-blog.php


Version 1.1
 * Long navigation pixes
 * excluded minified files

Version 1.0
* First public release